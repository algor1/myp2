from django.shortcuts import render, redirect

# Create your views here.
from tasks.models import Task, TaskForm, Images, ImagesForm
from django.views.generic import ListView, DetailView
from django.utils import timezone

class TasksListView(ListView):
    model = Task              

class TaskDetailView(DetailView):
    model = Task

class ImagesListView(ListView):
    model = Images              

def task_new(request):
        if request.method == "POST":
            form = TaskForm(request.POST)
            if form.is_valid():
                Task = form.save(commit=False)
                Task.user = request.user
                Task.pub_date = timezone.now()

                if not Task.title:
                	Task.title=Task.task_text[:50]
		
                Task.save()
                return redirect('image_new')
        else:
            form = TaskForm()
        return render(request,  'tasks/task_new.html', {'form': form})

def image_new(request):
        if request.method == "POST":
            form = ImagesForm(request.POST)
            if form.is_valid():
                Images = form.save(commit=False)
		
                Images.save()
                return redirect('list')
        else:
            form = ImagesForm()
        return render(request,  'tasks/image_new.html', {'form': form})

